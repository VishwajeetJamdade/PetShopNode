-- DropIndex
DROP INDEX "public"."Pet_age_idx";

-- DropIndex
DROP INDEX "public"."Pet_type_idx";
